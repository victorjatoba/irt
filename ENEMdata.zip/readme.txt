Arquivo matriz.txt:
- em cada linha está o resultado (acertou-1 ou errou-0) para cada uma das 175 questões
- há dados de 1414 alunos

Arquivo areas.txt:
- está indicada a área de cada uma das 175 questões
- 1 para 'CH', 2 para 'CN', 3 para 'MT' e 4 para 'LC'
